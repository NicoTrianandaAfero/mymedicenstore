 
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Selamat Datang di BoBoBooy Quiz!</title>
	<style type="text/css">
	.btn {
 
  border: 2px solid #e74c3c;
  border-radius: 0.6em;
  color: #e74c3c;
  cursor: pointer;
  display: flex;
  font-size: 1rem;
  margin: 20px;
  padding: 1.2em 2.8em;
  text-decoration: none;
  text-transform: uppercase;
  font-weight: 700;
}
.btn:hover, .btn:focus {
  color: #fff;
  outline: 0;
}

</style>
</head>
<body>
	<form action="quiz.php">
		<h1>Hallo, ayo mulai kuis! semoga beruntung</h1>
		<button class="btn second">Play To Quis</button>
	</form>
</body>
</html>