<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Kesimpulan</title>
</head>
<body>
<h1>Kesimpulan Soal BoBoiBoy Fun Quiz</h1>
<p>Selamat Anda Telah Selesai Mengerjakan Soal</p>
<form action="index.php">
    <input type="submit" value="Back To Home" />
</form>
</body>
</html>