<!DOCTYPE html>
<html>

<head>
    <title>FSP - Database</title>
</head>

<body>
    <?php
    $koneksi = new mysqli("localhost", "root", "", "students");

    if ($koneksi->connect_errno) {
        die("Failed to connect to MySQL: " . $koneksi->connect_error);
    }

    $nrp = $_POST['nrp'];
    $name = $_POST['name'];
    $ipk = $_POST['ipk'];
    $birthdate = $_POST['birthdate'];
    $faculty = $_POST['faculty'];
     
  

    $sql = "INSERT INTO students(nrp,name,ipk,birthdate,faculty_id) VALUES (?,?,?,?,?)";
    $hasil = $koneksi->prepare($sql);
    $hasil->bind_param("ssdsi", $nrp, $name, $ipk, $birthdate, $faculty);
    $hasil->execute();

    if ($hasil->error != true) {
        echo "Insert Success : " . $hasil->affected_rows . "<br>";
      
        echo "Nrp student baru : " .$nrp;
 
        $hasil = $koneksi->prepare($sql);

 
    } else
        echo "Insert Failed : " . $koneksi->error;

    $koneksi->close();
    ?>
    <br>
    <a href="index_160719036.php">Back</a>
</body>

</html>