<!DOCTYPE html>
<html>

<head>
    <title>Insert_160719036</title>
    <style type="text/css">
        table,
        td,
        th {
            border: 1px solid black;
        }
        .form-group {
            clear: both;
            padding: 2px;
        }

        .form-label {
            display: block;
            float: left;
            width: 20%;
        }

        div#file_upload {
            float: left;
        }

        div#file_upload input {
            display: block;
            margin-bottom: 5px;
        }
    </style>
</head>

<body>
    <form method="POST" enctype="multipart/form-data" action="insertproses_160719036.php">
        <div class="form-group">
            <label class="form-label">Nrp</label>
            <input type="text" name="nrp">
        </div>
        <div class="form-group">
            <label class="form-label">Name</label>
            <input type="text" name="name">
        </div>
        <div class="form-group">
            <label class="form-label">ipk</label>
            <input type="text" name="ipk">
        </div>
        <div class="form-group">
            <label class="form-label">Birthdate</label>
            <input type="date" name="birthdate">
        </div>
        
        <!-- combobox faculty -->
        <div class="form-group">
            <label class="form-label">Faculty</label>
            <?php
            $koneksi = new mysqli("localhost", "root", "", "students");

            $sql = "SELECT * FROM faculty";
            $hasil = $koneksi->query($sql);

            echo "<select>";
            while ($baris = $hasil->fetch_assoc()) {
                $id = $baris['id'];
                $name = $baris['name'];

                echo "<option type='combobox' name='faculty' value='$id'>$name </option>";
            }
            echo "</select>";
            ?>

        </div>    
         
        <div class="form-group">
            <input type="submit" name="submit" value="Tambah Student">
        </div>
    </form>
    <script src="jquery-3.5.1.min.js"></script>
   
</body>

</html>