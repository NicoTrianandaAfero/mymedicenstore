<!DOCTYPE html>
<html>

<head>
    <title>index_160719036</title>
    <style type="text/css">
        table,
        td,
        th {
            border: 1px solid black;
        }

        ul {
            list-style-type: none;
        }

        li {
            display: inline-block;
            padding: 6px 9px;
            border: 1px solid #dedfe1;
        }

        li:hover {
            background-color: #e3e4e8;
        }

        li.active {
            background-color: #367afd;
            color: #fff;
        }

        li a {
            text-decoration: none;
            color: #367afd;
        }

        li:first-child {
            border-radius: 5px 0 0 5px;
        }

        li:last-child {
            border-radius: 0 5px 5px 0;
        }
    </style>
</head>

<body>
    <?php
    $koneksi = new mysqli("localhost", "root", "", "students");

    if ($koneksi->connect_errno) {
        die("Failed to connect to MySQL: " . $koneksi->connect_error);
    }

    echo "<br>Data Student<br>";
 
    $name = (isset($_GET['name'])) ? $_GET['name'] : '';
    $sql = "SELECT * FROM students WHERE name LIKE '%$name%'";
    $hasil = $koneksi->query($sql);
    $jumdata = $hasil->num_rows;
    $perpage = (isset($_GET['datapage'])) ? $_GET['datapage'] : 10;

    $nrp = (isset($_GET['nrp'])) ? $_GET['nrp'] : '';
    $sql = "SELECT * FROM students WHERE nrp LIKE '%$nrp%'";
    $hasil = $koneksi->query($sql);
    $jumdata = $hasil->num_rows;
    $perpage = (isset($_GET['datapage'])) ? $_GET['datapage'] : 10;
 
    ?>

    Berdasarkan Nama : 
    <form method="get" action="">
        Keyword: <input type="text" name="name" value="<?= $name ?>" /> |
        
      
        <input type="submit" name="submit" value="Apply">
    </form>
    <br>
    Berdasarkan Nrp :
     <form method="get" action="">
        Keyword: <input type="text" name="nrp" value="<?= $nrp ?>" /> |
        
      
        <input type="submit" name="submit" value="Apply">
    </form>
    <br>
    <?php
    $p = (isset($_GET['p'])) ? $_GET['p'] : 1; // halaman saat ini
    $jumpage = ceil($jumdata / $perpage);
    //echo "$perpage $jumdata $jumpage";

    if ($jumpage <= 5) {
        $firstpage = 1;
        $lastpage = $jumpage;
    }
    // jumlah page lebih dari 5
    else {
        if ($p <= 3) {
            $firstpage = 1;
            $lastpage = 5;
        }
        // cek apakah halaman selanjutnya melebihi jumlah page
        else if ($p + 1 >= $jumpage) {
            $lastpage = $jumpage;
            $firstpage = $lastpage - 4;
        }
        // halaman saat ini lebih dari 3
        else {
            $firstpage = $p - 2;
            $lastpage = $p + 2;
        }
    }


    echo "<ul>";

    $prev = $p - 1;
    $next = $p + 1;
    if ($p > 1)
        echo "<li><a href='?name=$name&datapage=$perpage&p=$prev'>Previous</a></li>";

    for ($i = $firstpage; $i <= $lastpage; $i++) {
        if ($i == $p)
            echo "<li class='active'>$i</li>";
        else
            echo "<li><a href='?name=$name&datapage=$perpage&p=$i'>$i</a></li>";
    }

    if ($p < $jumpage)
        echo "<li><a href='?name=$name&datapage=$perpage&p=$next'>Next</a></li>";

    echo "</ul>";
    ?>
    <br>
    <?php

    $awal = ($p - 1) * $perpage; //offset 

    $sql = "SELECT * FROM students WHERE name LIKE '%$name%' LIMIT $awal,$perpage";
    $hasil = $koneksi->query($sql);

    echo "<table>";
    echo "<tr><th>Nrp</th><th>Name</th><th>ipk</th><th>Birthday</th><th>faculty</th><th>Aksi</th></tr>";

    while ($baris = $hasil->fetch_assoc()) {
        echo "<tr>";

        $name = $baris['name'];
       
        $sql = 'SELECT * FROM students WHERE name = ?';
        $stmt = $koneksi->prepare($sql);
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $result = $stmt->get_result();
       
        
        echo "<td>" . $baris["nrp"] . "</td>";
        echo "<td>" . $baris["name"] . "</td>";
        echo "<td>" . $baris["ipk"] . "</td>";
        echo "<td>" . date("d F Y", strtotime($baris["birthdate"])) . "</td>";
      

        $sql2 = "SELECT F.name FROM faculty as F INNER JOIN students as S ON F.id=S.faculty_id WHERE S.nrp=" . $baris['nrp'];
        $hasil2 = $koneksi->query($sql2);
        echo "<td>";
        while ($baris2 = $hasil2->fetch_assoc()) {
            echo "|" . $baris2["name"] . "|";
        }
        echo "</td>";
        echo "<td>";
        echo "<a href='editform.php?id=$name'>Edit</a> ";
        echo "<a href='deleteform.php?id=$name'>Delete</a> ";
        echo "</td>";
        echo "</tr>";
    }

    echo "</table>";

    $koneksi->close();
    ?>
    <br>
    <a href="insert_160719036.php">Tambah Student</a>

</body>

</html>