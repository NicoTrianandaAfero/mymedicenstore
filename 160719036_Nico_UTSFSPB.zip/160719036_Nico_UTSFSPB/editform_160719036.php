<!DOCTYPE html>
<html>

<head>
    <title>editform_160719036</title>
    <style type="text/css">
        .form-group {
            clear: both;
            padding: 2px;
        }

        .form-label {
            display: block;
            float: left;
            width: 20%;
        }

        div.div-control {
            float: left;
        }

        
        div#file_upload div {
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <?php
    $koneksi = new mysqli("localhost", "root", "", "students");

    if ($koneksi->connect_errno) {
        die("Failed to connect to MySQL: " . $koneksi->connect_error);
    }
     ?>

     
    $name = (isset($_GET['name'])) ? $_GET['name'] : '';
    $sql = "SELECT * FROM students WHERE name=$name";
    $hasil = $koneksi->query($sql);
  
    if ($baris = $hasil->fetch_assoc()) {
   

        <form method="POST" enctype="multipart/form-data" action="editproses_160719036.php">
            <div class="form-group">
                <label class="form-label">Nrp</label>
                <input type="text" name="judul" value="<?= $baris['nrp'] ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Name</label>
                <input type="text" name="name" value="<?= $baris['name'] ?>">
            </div>
            <div class="form-group">
                <label class="form-label">ipk</label>
                <input type="text" name="ipk" value="<?= $baris['ipk'] ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Birthdya</label>
                <input type="date" name="birthdate" value="<?= $baris['birthdate'] ?>">
            </div>
            <div class="form-group">
                <label class="form-label">Faculty</label>
                <input type="text" name="faculty" value="<?= $baris['faculty'] ?>"> 
               
               
            </div>
            <!-- combobox genre -->
            <div class="form-group">
                <label class="form-label">Faculty</label>
                <?php

               $sql2 = "SELECT F.name FROM faculty as F INNER JOIN students as S ON F.id=S.faculty_id WHERE S.nrp=" . $baris['nrp'];
                $hasil2 = $koneksi->query($sql2);

                echo "<select>";
                while ($baris2 = $hasil2->fetch_assoc()) {
                    $id= $baris2['id'];
                    $nama = $baris2['name'];

                   
                    echo "<option type='combobox' name='faculty' value='$id'>$name </option>";
                }
                echo "</select>";
                ?>

            </div>
                  
            <div class="form-group">
                
                <input type="submit" name="submit" value="back">
            </div>
        </form>
     
    <script src="jquery-3.5.1.min.js"></script>

</body>
</html>